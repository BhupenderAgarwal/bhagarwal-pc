#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      gyerroju
#
# Created:     16/11/2012
# Copyright:   (c) gyerroju 2012
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import os, shutil

def main():
    # parse txt file into req array
    f = open('C:/Users/gyerroju/Desktop/EL/i.txt')
    req = f.readlines()
    f.close()
    # get file list from ExcelLink into src
    src = os.listdir('C:/Users/gyerroju/Desktop/EL/ExcelLink')
    # loop through src and move required files to Result
    for fname in src:
        nm = fname.split('.')[0]
        for tmp in req:
            nm2 = tmp.strip('\n')
            # if match, move to Result
            if nm == nm2:
                source = 'C:/Users/gyerroju/Desktop/EL/ExcelLink/%s.sj' % nm
                dest = 'C:/Users/gyerroju/Desktop/EL/Result/%s.sj' % nm
                shutil.move(source, dest)
                # remove the found file name from the required list
                req.remove(tmp)
                break
    print req

if __name__ == '__main__':
    main()
