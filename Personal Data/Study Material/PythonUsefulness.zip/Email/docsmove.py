#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      gyerroju
#
# Created:     16/11/2012
# Copyright:   (c) gyerroju 2012
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import os, shutil

def main():
    # parse txt file into req array
    f = open('E:\EL\RequiredList.txt')
    req = f.readlines()
    f.close()
    # get file list from ExcelLink into src
    src = os.listdir('C:\source\smqa\helios\TC8\_docs')
    # loop through src and move required files to Result
    for fname in src:
        nm = fname.split('.')[0]
        for tmp in req:
            nm2 = tmp.strip('\n')
            # if match, move to Result
            if nm == nm2:
                source = 'C:/source/smqa/helios/TC8/_docs/%s' % nm
                dest = 'C:/Users/simminni/Desktop/_docs/%s' % nm
                shutil.move(source, dest)
                # remove the found file name from the required list
                req.remove(tmp)
                break
    print req

if __name__ == '__main__':
    main()
